package timeouts;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/*
 * this class will demonstrate implicit wait based test Synchronization
 * @author Rachana
 * */
public class ImplicitWaitTest {
	static WebDriver driver =null;
	public static void main(String[] args) {
		setUp();
		testMobileNavlink();
		testFashionNavlink();
		
		driver.close();
	}

	public static void setUp()  {
		//step1: formulate a test domain url and driver path
				String siteUrl ="https://www.amazon.com/";
				String driverPath = "drivers\\windows\\chromedriver.exe";
				
				//step2: set system properties for selenium driver
				System.setProperty("webdriver.chrome.driver", driverPath);
				
				//step3 : instantiate selenium webdriver
				 driver = new ChromeDriver();
				
				 //step4: add implicit wait
				 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
				 
				//step5: launch browser
				driver.get(siteUrl);
	}			
	
	public static void testMobileNavlink() {
		
	WebElement mobileLink =	driver.findElement(By.cssSelector("#nav-xshop > a:nth-child(7)"));
		
	System.out.println("Is link Loaded :: "+mobileLink.isDisplayed());
	System.out.println("Is link enabled :: " +mobileLink.isEnabled());
	
	mobileLink.click();
	
	String expectedTitle = "Mobile Phones: Buy New Mobiles Online at Best Prices in India | Buy Cell Phones Online - Amazon.in";
	String actualTitle = driver.getTitle();
	
	if(expectedTitle.equals(actualTitle)) {
		System.out.println("Test is passed");
	}
	else {
		System.out.println("Test is Failed");
	}
	
	System.out.println("Expected Title :" + expectedTitle);
	System.out.println("Actual Title :" + actualTitle);

	}
	
	public static void testFashionNavlink() {
		
		WebElement fashionLink =	driver.findElement(By.cssSelector("#nav-xshop > a:nth-child(5)"));
			
		System.out.println("Is link Loaded :: "+fashionLink.isDisplayed());
		System.out.println("Is link enabled :: " +fashionLink.isEnabled());
		
		fashionLink.click();
		
		String expectedTitle = "Mobile Phones: Buy New Mobiles Online at Best Prices in India | Buy Cell Phones Online - Amazon.in";
		String actualTitle = driver.getTitle();
		
		if(expectedTitle.equals(actualTitle)) {
			System.out.println("Test is passed");
		}
		else {
			System.out.println("Test is Failed");
		}
		
		System.out.println("Expected Title :" + expectedTitle);
		System.out.println("Actual Title :" + actualTitle);

		}
	}
