package amazon;

import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.remote.http.WebSocket;
//import java.net.SocketException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

/*this class demonstrate test for amazon webpage
 * @author rachana
 * selenium webdriver
 * */

public class AmazonSearchTest {
	
	static WebDriver driver =null;

	public static void main(String[] args) throws InterruptedException {
		//step1: formulate a test domain url and driver path
				String siteUrl ="https://www.amazon.com/";
				String driverPath = "drivers\\windows\\chromedriver.exe";
				
				//step2: set system properties for selenium driver
				System.setProperty("webdriver.chrome.driver", driverPath);
				
				//step3 : instantiate selenium webdriver
				 driver = new ChromeDriver();
				
				//step4: launch browser
				driver.get(siteUrl);
				
				testSearch1();
				testSearch2();
				/*
				 * search for a product
				 * */
				
	}

	private static void testSearch1() throws InterruptedException {
		// TODO Auto-generated method stub
		WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
		searchBox.sendKeys("Iphone 15 pro max");
		searchBox.submit();
		
		//add delay
		Thread.sleep(2000);
		
		String expectedTitle = "Amazon.com : Iphone 15 pro max";
		String actualTitle = driver.getTitle();
		
		if(expectedTitle.equals(actualTitle)) {
			System.out.println("Test is passed");
		}
		else {
			System.out.println("Test is Failed");
		}
		
		System.out.println("Expected Title :" + expectedTitle);
		System.out.println("Actual Title :" + actualTitle);

	}
	private static void testSearch2() throws InterruptedException {
		// TODO Auto-generated method stub
		WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
		searchBox.clear();
		searchBox.sendKeys("Apple Mac Book");
		searchBox.submit();
		
		//add delay
		Thread.sleep(2000);
		
		String expectedTitle = "Amazon.com : Apple Mac Book";
		String actualTitle = driver.getTitle();
		
		if(expectedTitle.equals(actualTitle)) {
			System.out.println("Test is passed");
		}
		else {
			System.out.println("Test is Failed");
		}
		
		System.out.println("Expected Title :" + expectedTitle);
		System.out.println("Actual Title :" + actualTitle);

		driver.close();
	}
}
