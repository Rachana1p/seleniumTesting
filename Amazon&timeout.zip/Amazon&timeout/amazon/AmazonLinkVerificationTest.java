package amazon;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonLinkVerificationTest {
	static WebDriver driver =null;

	public static void main(String[] args) throws InterruptedException {
		//step1: formulate a test domain url and driver path
				String siteUrl ="https://www.amazon.com/";
				String driverPath = "drivers\\windows\\chromedriver.exe";
				
				//step2: set system properties for selenium driver
				System.setProperty("webdriver.chrome.driver", driverPath);
				
				//step3 : instantiate selenium webdriver
				 driver = new ChromeDriver();
				
				//step4: launch browser
				driver.get(siteUrl);
				
				LinkTest1();
				
				Thread.sleep(2000);

				LinkTest2();
				
				Thread.sleep(2000);

				driver.close();
				/*
				 * search for a product
				 * */
				
	}
/*
 * verify the Best seller Link
 * @throws InterruptedException
 * */
	private static void LinkTest1() throws InterruptedException {
		// TODO Auto-generated method stub
		WebElement link = driver.findElement(By.xpath("/html/body"));
		link.click();
		
		//add delay
		Thread.sleep(2000);
		
		String expectedTitle = "Amazon | Deals";
		String actualTitle = driver.getTitle();
		
		if(expectedTitle.equals(actualTitle)) {
			System.out.println("Test is passed");
		}
		else {
			System.out.println("Test is Failed");
		}
		
		System.out.println("Expected Title :" + expectedTitle);
		System.out.println("Actual Title :" + actualTitle);

	}
	private static void LinkTest2() throws InterruptedException {
		// TODO Auto-generated method stub
		WebElement link = driver.findElement(By.cssSelector("#nav-xshop > a:nth-child(6)"));
		link.click();
		
		//add delay
		Thread.sleep(2000);
		
		String expectedTitle = "Amazon.in: Amazon Fresh";
		String actualTitle = driver.getTitle();
		
		if(expectedTitle.equals(actualTitle)) {
			System.out.println("Test is passed");
		}
		else {
			System.out.println("Test is Failed");
		}
		
		System.out.println("Expected Title :" + expectedTitle);
		System.out.println("Actual Title :" + actualTitle);

		driver.close();
	}
}
