package amazon;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/*this class demonstrate test for amazon webpage
 * @author rachana
 * selenium webdriver
 * */

public class AmazonHomePageTest {
	public static void main(String[] args) {
		//step1: formulate a test domain url and driver path
				String siteUrl ="https://www.amazon.com/";
				String driverPath = "drivers\\windows\\chromedriver.exe";
				
				//step2: set system properties for selenium driver
				System.setProperty("webdriver.chrome.driver", driverPath);
				
				//step3 : instantiate selenium webdriver
				WebDriver driver = new ChromeDriver();
				
				//step4: launch browser
				driver.get(siteUrl);
				
				String expectedTitle = "Amazon.com. Spend less. Smile more.";
				String actualTitle = driver.getTitle();
				
				if(expectedTitle.equals(actualTitle)) {
					System.out.println("Test is passed");
				}
				else {
					System.out.println("Test is Failed");
				}
				
				System.out.println("Expected Title :" + expectedTitle);
				System.out.println("Actual Title :" + actualTitle);

				driver.close();
	}
}
